docker build . -t dalle-mini:latest
