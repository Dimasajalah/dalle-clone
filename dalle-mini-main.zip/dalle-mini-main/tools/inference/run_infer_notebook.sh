#!/bin/bash
jupyter notebook --ip 0.0.0.0 --no-browser --allow-root